"""
Predictive Sales Forecasting
Beginner-friendly time-series regression project.

Run:
    pip install -r requirements.txt
    python src/forecast_sales.py
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "monthly_sales.csv"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

def main():
    # 1. Load and clean data
    data = pd.read_csv(DATA_PATH)
    data["Date"] = pd.to_datetime(data["Date"], errors="coerce")
    data["Sales"] = pd.to_numeric(data["Sales"], errors="coerce")
    data = data.dropna(subset=["Date", "Sales"])
    data = data.drop_duplicates(subset=["Date"]).sort_values("Date").reset_index(drop=True)

    if len(data) < 12:
        raise ValueError("Please provide at least 12 months of valid sales data.")

    # Use a simple time index as the model feature.
    data["Month_Index"] = range(len(data))
    X = data[["Month_Index"]]
    y = data["Sales"]

    # 2. Chronological split: earlier months train; latest 20% test.
    split_index = int(len(data) * 0.8)
    X_train, X_test = X.iloc[:split_index], X.iloc[split_index:]
    y_train, y_test = y.iloc[:split_index], y.iloc[split_index:]

    # 3. Train and evaluate
    model = LinearRegression()
    model.fit(X_train, y_train)
    test_predictions = model.predict(X_test)

    mae = mean_absolute_error(y_test, test_predictions)
    rmse = mean_squared_error(y_test, test_predictions) ** 0.5
    r2 = r2_score(y_test, test_predictions)

    metrics = pd.DataFrame({
        "Metric": ["MAE", "RMSE", "R2 Score"],
        "Value": [mae, rmse, r2]
    })
    metrics.to_csv(OUTPUT_DIR / "evaluation_metrics.csv", index=False)

    test_results = data.iloc[split_index:][["Date", "Sales"]].copy()
    test_results["Predicted_Sales"] = test_predictions.round(2)
    test_results.to_csv(OUTPUT_DIR / "test_predictions.csv", index=False)

    # 4. Forecast the next six months
    future_steps = 6
    last_index = len(data) - 1
    future_indices = pd.DataFrame({"Month_Index": range(last_index + 1, last_index + 1 + future_steps)})
    future_dates = pd.date_range(data["Date"].max() + pd.offsets.MonthBegin(1),
                                 periods=future_steps, freq="MS")
    future_sales = model.predict(future_indices).round(2)
    forecast = pd.DataFrame({"Date": future_dates, "Forecast_Sales": future_sales})
    forecast["Date"] = forecast["Date"].dt.strftime("%Y-%m-%d")
    forecast.to_csv(OUTPUT_DIR / "future_sales_forecast.csv", index=False)

    # 5. Visualize historical sales, test predictions, and future forecast
    plt.figure(figsize=(11, 6))
    plt.plot(data["Date"], data["Sales"], marker="o", label="Historical sales")
    plt.plot(data.iloc[split_index:]["Date"], test_predictions,
             marker="s", linestyle="--", label="Test predictions")
    plt.plot(future_dates, future_sales, marker="^", linestyle="--",
             label="Next 6 months forecast")
    plt.title("Historical Sales and Future Forecast")
    plt.xlabel("Date")
    plt.ylabel("Sales")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "sales_forecast.png", dpi=150)
    plt.close()

    print("Predictive Sales Forecasting completed.")
    print(f"MAE: {mae:.2f}")
    print(f"RMSE: {rmse:.2f}")
    print(f"R2 Score: {r2:.3f}")
    print("\nNext six months forecast:")
    print(forecast.to_string(index=False))
    print(f"\nOutputs saved in: {OUTPUT_DIR}")

if __name__ == "__main__":
    main()
