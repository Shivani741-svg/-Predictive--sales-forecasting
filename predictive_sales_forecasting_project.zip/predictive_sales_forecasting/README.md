# Predictive Sales Forecasting Using Historical Data

## Project objective
This beginner-friendly BTech CSE project uses historical monthly sales data to forecast the next six months. It demonstrates data cleaning, regression, model evaluation, and visualization.

## Tools and technologies
- Python
- Pandas and NumPy
- Matplotlib
- Scikit-learn (Linear Regression)

## Project structure
```text
predictive_sales_forecasting/
├── data/
│   └── monthly_sales.csv
├── outputs/
│   └── (generated after running the script)
├── src/
│   └── forecast_sales.py
├── requirements.txt
└── README.md
```

## How to run
1. Install Python 3.10 or later.
2. Open a terminal in this project folder.
3. Install the libraries:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the project:
   ```bash
   python src/forecast_sales.py
   ```

## What the program does
1. Reads the monthly sales CSV.
2. Converts dates and sales to valid data types.
3. Removes rows with missing date/sales values and duplicate dates.
4. Splits data chronologically into training and testing sets.
5. Trains a Linear Regression model.
6. Evaluates predictions using MAE, RMSE, and R².
7. Forecasts sales for the next six months.
8. Saves CSV results and a graph in `outputs/`.

## Output files
- `evaluation_metrics.csv`: model evaluation scores.
- `test_predictions.csv`: actual and predicted values for the test period.
- `future_sales_forecast.csv`: next six months of forecasts.
- `sales_forecast.png`: historical sales and predicted trends chart.

## Dataset note
The included monthly dataset is synthetic sample data created for learning and demonstration. Replace it with a real sales dataset before making real business decisions.

## Model limitations
Linear Regression assumes a roughly linear trend and does not fully model seasonal patterns. The scores describe performance on this illustrative dataset, not guaranteed real-world accuracy. For stronger forecasting, compare against seasonal-naive forecasts, Random Forest, or time-series methods and validate on multiple time periods.

## Short explanation for viva
"This project predicts future sales from historical monthly sales. I first cleaned the data, then used a chronological train-test split to avoid training on future records. I trained a Linear Regression model using the month index as a feature. I evaluated it using MAE, RMSE, and R², and plotted historical sales, test predictions, and a six-month forecast. The current dataset is synthetic, so a real dataset would be needed for practical business forecasting."
